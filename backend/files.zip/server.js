// server.js — EXAMPLE ENTRY POINT for local testing / reference only.
// In your real Render backend, apply applyCoreMiddleware() and mount
// these two routers into your EXISTING app.js/server.js instead of
// replacing it wholesale — this file just proves the pieces work together.

require('dotenv').config();
const express = require('express');
const { applyCoreMiddleware } = require('./middleware/setup');
const authRouter = require('./routes/auth');
const aiRouter = require('./routes/ai');

const app = express();
applyCoreMiddleware(app);

app.use('/api/auth', authRouter);
app.use('/api', aiRouter); // exposes POST /api/ai/messages

app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`DRAPE backend patch listening on :${PORT}`));
