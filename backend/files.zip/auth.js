// routes/auth.js
//
// Drop-in replacement for your existing /api/auth/* routes. The contract
// with the frontend (DRAPE_FashionOS_v4_fixed.html) is:
//   - POST /login, /register  -> { user, accessToken }   (refreshToken now
//     goes ONLY in an httpOnly cookie, not in the JSON body)
//   - POST /refresh           -> { accessToken }          (reads the cookie)
//   - POST /logout            -> clears the cookie
//   - GET  /me                -> { user }                 (needs Bearer accessToken)
//
// Replace the `users` Map and bcrypt/JWT calls below with your real
// database + user model — this file focuses on the cookie/token
// mechanics, which is the part that actually needed fixing.

const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const router = express.Router();

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || 'dev-only-access-secret-change-me';
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev-only-refresh-secret-change-me';
const ACCESS_TTL = '15m';
const REFRESH_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const REFRESH_COOKIE_NAME = 'drape_refresh';

// ── REPLACE THIS with your real user store / DB lookup ──
const users = new Map(); // email -> { id, email, passwordHash, fname, lname, phone, role }
let nextId = 1;

// tracks which refresh tokens are currently valid, so /logout and token
// rotation can actually invalidate a token server-side (not just let it
// expire on its own). Replace with a DB table / Redis set in production.
const validRefreshTokens = new Set();

function cookieOptions() {
  const isProd = process.env.NODE_ENV === 'production';
  return {
    httpOnly: true,           // <- the actual fix: JS on the page cannot read this
    secure: isProd,           // requires HTTPS in production (Render gives you this)
    sameSite: isProd ? 'None' : 'Lax', // 'None' needed if frontend/backend are different origins
    path: '/api/auth',        // only sent to auth routes, not every request
    maxAge: REFRESH_TTL_MS,
  };
}

function signAccessToken(user) {
  return jwt.sign({ sub: user.id, role: user.role }, ACCESS_SECRET, { expiresIn: ACCESS_TTL });
}
function signRefreshToken(user) {
  const token = jwt.sign({ sub: user.id }, REFRESH_SECRET, { expiresIn: '30d' });
  validRefreshTokens.add(token);
  return token;
}
function publicUser(u) {
  const { passwordHash, ...pub } = u;
  return pub;
}

// ── POST /register ──
router.post('/register', async (req, res) => {
  const { fname, lname, email, phone, password } = req.body || {};
  if (!fname || !lname || !email || !phone || !password) {
    return res.status(400).json({ error: 'All fields are required.' });
  }
  if (users.has(email.toLowerCase())) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }
  const passwordHash = await bcrypt.hash(password, 10);
  const user = { id: 'cust-' + nextId++, email, passwordHash, fname, lname, phone, role: 'customer' };
  users.set(email.toLowerCase(), user);

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  res.cookie(REFRESH_COOKIE_NAME, refreshToken, cookieOptions());
  res.json({ user: publicUser(user), accessToken });
});

// ── POST /login ──
router.post('/login', async (req, res) => {
  const { username, password } = req.body || {}; // frontend sends email as "username"
  const user = users.get((username || '').toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);
  res.cookie(REFRESH_COOKIE_NAME, refreshToken, cookieOptions());
  res.json({ user: publicUser(user), accessToken });
});

// ── POST /refresh ── reads the cookie, never the body
router.post('/refresh', (req, res) => {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];
  if (!token || !validRefreshTokens.has(token)) {
    return res.status(401).json({ error: 'No valid session.' });
  }
  try {
    const payload = jwt.verify(token, REFRESH_SECRET);
    const user = [...users.values()].find(u => u.id === payload.sub);
    if (!user) return res.status(401).json({ error: 'No valid session.' });

    // Rotate the refresh token on every use — limits the damage window if
    // a token is ever stolen, since the old one stops working immediately.
    validRefreshTokens.delete(token);
    const newRefreshToken = signRefreshToken(user);
    res.cookie(REFRESH_COOKIE_NAME, newRefreshToken, cookieOptions());

    res.json({ accessToken: signAccessToken(user) });
  } catch (e) {
    return res.status(401).json({ error: 'Session expired.' });
  }
});

// ── POST /logout ── clears the cookie and invalidates the token server-side
router.post('/logout', (req, res) => {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];
  if (token) validRefreshTokens.delete(token);
  res.clearCookie(REFRESH_COOKIE_NAME, { path: '/api/auth' });
  res.json({ ok: true });
});

// ── GET /me ── requires a valid access token (Authorization: Bearer ...)
router.get('/me', (req, res) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token.' });
  try {
    const payload = jwt.verify(token, ACCESS_SECRET);
    const user = [...users.values()].find(u => u.id === payload.sub);
    if (!user) return res.status(401).json({ error: 'Invalid token.' });
    res.json({ user: publicUser(user) });
  } catch (e) {
    res.status(401).json({ error: 'Invalid or expired token.' });
  }
});

module.exports = router;
