# DRAPE backend patch — AI proxy + cookie-based refresh auth

This was tested end-to-end in a sandbox (register → refresh → logout →
refresh-after-logout correctly rejected → AI proxy fails gracefully
without a key). Drop the pieces into your **existing** Render backend —
don't replace your whole server with `server.js`, which is just a
runnable reference showing how the pieces wire together.

## 1. Install dependencies

```
npm install cors cookie-parser jsonwebtoken bcryptjs @anthropic-ai/sdk
```

## 2. Environment variables (set these in Render's dashboard, not in code)

| Variable | Purpose |
|---|---|
| `ANTHROPIC_API_KEY` | Your real Claude API key — never in frontend code |
| `JWT_ACCESS_SECRET` | Random secret for signing short-lived access tokens |
| `JWT_REFRESH_SECRET` | Random secret for signing refresh tokens (different from above) |
| `FRONTEND_ORIGIN` | Exact origin serving the HTML, e.g. `https://drape-fashion-os.onrender.com` |
| `NODE_ENV` | Set to `production` on Render so cookies get `Secure` + `SameSite=None` |

## 3. Wire into your existing app

```js
const { applyCoreMiddleware } = require('./middleware/setup');
const authRouter = require('./routes/auth');
const aiRouter = require('./routes/ai');

applyCoreMiddleware(app);   // BEFORE your other routes
app.use('/api/auth', authRouter);
app.use('/api', aiRouter);  // exposes POST /api/ai/messages
```

If you already have `/api/auth/*` routes, replace them with `routes/auth.js`
rather than mounting both — you want one source of truth for tokens.

## 4. Replace the in-memory user store

`routes/auth.js` currently uses a `Map` for users so it's runnable/testable
standalone. Swap the marked section for your real DB calls
(`users.get(...)` → your ORM's `findByEmail`, etc.) — the token/cookie
logic around it doesn't need to change.

## 5. What this actually fixes

- **AI proxy**: the frontend's `callClaudeAI()` now calls
  `POST /api/ai/messages` on your own server, which holds
  `ANTHROPIC_API_KEY` — the key never reaches the browser.
- **Refresh token**: instead of returning it in the JSON body (where the
  frontend used to store it in `localStorage`, readable by any XSS bug),
  it's now set as an `httpOnly` cookie scoped to `/api/auth`. JS on the
  page cannot read it at all. Tokens also rotate on every refresh and are
  invalidated server-side on logout, so a captured token doesn't work
  indefinitely even if it did leak some other way.

## 6. Quick manual test once deployed

```
curl -i -c cookies.txt -X POST https://your-backend/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fname":"Test","lname":"User","email":"t@example.com","phone":"+8801700000000","password":"secret123"}'
# check the Set-Cookie header includes: HttpOnly; Secure; SameSite=None

curl -i -b cookies.txt -X POST https://your-backend/api/auth/refresh
# should return a fresh accessToken

curl -i -b cookies.txt -X POST https://your-backend/api/auth/logout
curl -i -b cookies.txt -X POST https://your-backend/api/auth/refresh
# should now 401 — token was invalidated, not just cookie-cleared
```
