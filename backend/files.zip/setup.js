// middleware/setup.js
//
// Wire this into your existing Express app BEFORE mounting any routes.
// This is what makes the httpOnly refresh-cookie flow work at all —
// without exact-origin CORS + credentials:true, the browser will silently
// refuse to send/receive the cookie no matter what the routes do.

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

function applyCoreMiddleware(app) {
  const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'https://drape-fashion-os.onrender.com';

  app.use(cors({
    origin: FRONTEND_ORIGIN, // must be an exact origin, NOT '*', when credentials:true
    credentials: true,
  }));
  app.use(cookieParser());
  app.use(express.json());
}

module.exports = { applyCoreMiddleware };
