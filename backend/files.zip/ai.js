// routes/ai.js
//
// Backend proxy for every AI feature in the app (CRM assistant, social
// caption generator, accounting agent, SEO/social agent). The frontend's
// callClaudeAI() helper posts here instead of hitting api.anthropic.com
// directly, so the real API key never has to leave the server.

const express = require('express');
const Anthropic = require('@anthropic-ai/sdk');

const router = express.Router();
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

router.post('/ai/messages', async (req, res) => {
  const { system, messages, max_tokens } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'messages array is required.' });
  }
  try {
    const msg = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: Math.min(max_tokens || 1000, 4096), // cap to avoid runaway cost per request
      ...(system ? { system } : {}),
      messages,
    });
    res.json(msg);
  } catch (e) {
    console.error('AI proxy error:', e.message);
    res.status(500).json({ error: 'AI request failed' });
  }
});

module.exports = router;
